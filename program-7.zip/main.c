
#include <stdio.h>

int main()
{ int a,b,c,p;
 scanf("%d",&a);
  scanf("%d",&b);
   scanf("%d",&c);
   
    p =(a*b)-(a*c+100);
    printf("%d",p);
    return 0;
}
