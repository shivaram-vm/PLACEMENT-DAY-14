
#include <stdio.h>

int main()
{
   
   float principle,rate,time,simint,amount,discount,finamt;
   scanf("%f",&principle);
   scanf("%f",&rate);
   scanf("%f",&time);
   
   simint= (principle *rate*  time)/100;
   amount=principle+simint;
   discount=(2*simint)/100;
   finamt=amount-discount;
   
   printf("%.2f\n",simint);
    printf("%.2f\n",amount);
     printf("%.2f\n",discount);
    printf("%.2f\n",finamt);
   
    return 0;
}
