#include <stdio.h>

int main()
{
    int n, op;
    scanf("%d %d", &n, &op);

    int a[n]; 
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    for (int j = 0; j < op; j++) {
        int start, end, count = 0;
        scanf("%d %d", &start, &end);

        for (int i = 0; i < n; i++) {
            if (a[i] >= start && a[i] <= end) {
                count++;
            }
        }

        printf("%d\n", count);
    }

    return 0;
}
