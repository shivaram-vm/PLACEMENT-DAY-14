
#include <stdio.h>

int main()
{
    int n;
     scanf("%d",&n);
     
     printf("%c",n);

    return 0;
}
