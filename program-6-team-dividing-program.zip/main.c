
#include <stdio.h>

int main()
{
     int n,a,b,c;
    scanf("%d",&n);
    scanf("%d",&a);
    
    b=n/a;
    c=n%a;
    
 printf("%d\n",b);
  printf("%d",c);
 
    return 0;
}
