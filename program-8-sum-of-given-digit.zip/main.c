#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int n,rem,mul=1;
  scanf("%d",&n);
    for(int i=0;n>0;i++){
        rem=n%10;
        mul=mul*rem;
        n=n/10;
    }
    printf("%d",mul);
    
    return 0;
}
