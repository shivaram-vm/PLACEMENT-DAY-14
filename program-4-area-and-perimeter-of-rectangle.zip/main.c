
#include <stdio.h>

int main()
{
    int l,b,p,a;
    scanf("%d",&l);
    scanf("%d",&b);
    
     p=2*(l+b);
     a=l*b;
     printf("%d\n",p);
     printf("%d",a);

    return 0;
}
