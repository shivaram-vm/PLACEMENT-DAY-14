#include <stdio.h>
#include <math.h>

int main()
{
   float a1, a2, a3, b1, b2, b3, area, x, y, z, r;

   scanf("%f", &a1);
   scanf("%f", &b1);
   scanf("%f", &a2);
   scanf("%f", &b2);
   scanf("%f", &a3);
   scanf("%f", &b3);
   
   area = 0.5 * (a1*(b2 - b3) + a2*(b3 - b1) + a3*(b1 - b2));  
   x = sqrt((a3 - a2)*(a3 - a2) + (b3 - b2)*(b3 - b2));
   y = sqrt((a3 - a1)*(a3 - a1) + (b3 - b1)*(b3 - b1));
   z = sqrt((a2 - a1)*(a2 - a1) + (b2 - b1)*(b2 - b1));
   
   r = (x * y * z) / (4 * area);  

   printf("Area: %.2f\n", area);
   printf("r: %.2f\n", r);

   return 0;
}
